if (file.exists((privtest <- "C:/home/francois/travail/stats/spaMMplus/spaMM/package/tests_other_pack/test-DHARMa.R"))) {
  source(privtest) 
}
