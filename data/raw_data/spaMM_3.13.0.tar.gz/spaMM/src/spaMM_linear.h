#ifndef _lmwithQ_H
#define _lmwithQ_H

#include <RcppEigen.h>
#include <Rcpp.h>

extern bool printDebug;

#endif
