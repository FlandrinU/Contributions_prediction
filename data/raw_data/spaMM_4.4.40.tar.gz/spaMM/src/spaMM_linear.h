#ifndef _lmwithQ_H
#define _lmwithQ_H

#include <RcppEigen.h>
#include <Rcpp.h>
// #include <omp.h> // Apparently not needed (Eigen copes with that). See help("setNbThreads") for this parallel feature. 

extern bool printDebug;

#endif
